###
###  FairDB utilities
###